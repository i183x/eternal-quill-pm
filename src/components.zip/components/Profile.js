// src/components/Profile.js
import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { doc, getDoc, collection, getDocs, updateDoc } from 'firebase/firestore';
import { useParams } from 'react-router-dom';

function Profile() {
  const { id } = useParams();
  const [user, setUser] = useState(null);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  // Replace this with the actual current user ID
  const currentUserId = "yourUserId";

  useEffect(() => {
    const fetchUser = async () => {
      const userDoc = await getDoc(doc(db, "users", id));
      if (userDoc.exists()) {
        setUser(userDoc.data());
      } else {
        console.log("No such user!");
      }
    };

    const fetchPosts = async () => {
      const postsQuery = collection(db, "posts");
      const postsSnapshot = await getDocs(postsQuery);
      const userPosts = postsSnapshot.docs
        .filter(postDoc => postDoc.data().userId === id)
        .map(postDoc => ({
          id: postDoc.id,
          ...postDoc.data()
        }));
      setPosts(userPosts);
      setLoading(false);
    };

    fetchUser();
    fetchPosts();
  }, [id]);

  const handleFollow = async () => {
    if (!user) return;

    const currentUserDoc = await getDoc(doc(db, "users", currentUserId));
    if (currentUserDoc.exists()) {
      const currentUserData = currentUserDoc.data();
      let updatedFollowing;

      if (currentUserData.following.includes(id)) {
        updatedFollowing = currentUserData.following.filter(userId => userId !== id);
      } else {
        updatedFollowing = [...currentUserData.following, id];
      }

      await updateDoc(doc(db, "users", currentUserId), {
        following: updatedFollowing
      });
    }
  };

  return (
    <div className="profile">
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div>
          {user && (
            <div>
              <img src={user.profilePictureURL} alt={`${user.username}'s profile`} />
              <h2>{user.username}</h2>
              <p>{user.bio}</p>
              <button onClick={handleFollow}>
                {user.followers && user.followers.includes(currentUserId) ? "Unfollow" : "Follow"}
              </button>
            </div>
          )}
          <h3>Posts</h3>
          <ul>
            {posts.map(post => (
              <li key={post.id}>
                <h4>{post.title}</h4>
                <p>{post.content}</p>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default Profile;
