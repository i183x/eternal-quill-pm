// src/components/AdminDashboard.js
import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, getDocs, deleteDoc, doc, addDoc, updateDoc, arrayUnion } from 'firebase/firestore';

function AdminDashboard() {
  const [competitions, setCompetitions] = useState([]);
  const [users, setUsers] = useState([]);
  const [posts, setPosts] = useState([]);
  const [panelists, setPanelists] = useState([]);
  const [newCompetition, setNewCompetition] = useState({
    name: '',
    description: '',
    rules: '',
  });
  const [selectedCompetitionId, setSelectedCompetitionId] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const competitionsSnapshot = await getDocs(collection(db, "competitions"));
      const usersSnapshot = await getDocs(collection(db, "users"));
      const postsSnapshot = await getDocs(collection(db, "posts"));

      const allPanelists = usersSnapshot.docs.filter(doc => doc.data().role === 'panelist');

      setCompetitions(competitionsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setUsers(usersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setPosts(postsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setPanelists(allPanelists.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    };

    fetchData();
  }, []);

  const handleDeleteCompetition = async (competitionId) => {
    await deleteDoc(doc(db, "competitions", competitionId));
    setCompetitions(competitions.filter(competition => competition.id !== competitionId));
  };

  const handleDeleteUser = async (userId) => {
    await deleteDoc(doc(db, "users", userId));
    setUsers(users.filter(user => user.id !== userId));
  };

  const handleDeletePost = async (postId) => {
    await deleteDoc(doc(db, "posts", postId));
    setPosts(posts.filter(post => post.id !== postId));
  };

  const handleCreateCompetition = async () => {
    await addDoc(collection(db, "competitions"), {
      ...newCompetition,
      createdAt: new Date(),
    });
    setNewCompetition({ name: '', description: '', rules: '' });
    const competitionsSnapshot = await getDocs(collection(db, "competitions"));
    setCompetitions(competitionsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
  };

  const handleAssignPanelist = async (competitionId, panelistId) => {
    const competitionRef = doc(db, "competitions", competitionId);
    await updateDoc(competitionRef, {
      panelists: arrayUnion(panelistId)
    });
  };

  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div>
          <h3>Manage Competitions</h3>
          <ul>
            {competitions.map(competition => (
              <li key={competition.id}>
                <p>{competition.name}</p>
                <button onClick={() => handleDeleteCompetition(competition.id)}>Delete</button>
              </li>
            ))}
          </ul>

          <h3>Create New Competition</h3>
          <input
            type="text"
            placeholder="Competition Name"
            value={newCompetition.name}
            onChange={(e) => setNewCompetition({ ...newCompetition, name: e.target.value })}
          />
          <textarea
            placeholder="Description"
            value={newCompetition.description}
            onChange={(e) => setNewCompetition({ ...newCompetition, description: e.target.value })}
          />
          <textarea
            placeholder="Rules"
            value={newCompetition.rules}
            onChange={(e) => setNewCompetition({ ...newCompetition, rules: e.target.value })}
          />
          <button onClick={handleCreateCompetition}>Create Competition</button>

          <h3>Manage Users</h3>
          <ul>
            {users.map(user => (
              <li key={user.id}>
                <p>{user.username}</p>
                <button onClick={() => handleDeleteUser(user.id)}>Delete</button>
              </li>
            ))}
          </ul>

          <h3>Manage Posts</h3>
          <ul>
            {posts.map(post => (
              <li key={post.id}>
                <p>{post.title}</p>
                <button onClick={() => handleDeletePost(post.id)}>Delete</button>
              </li>
            ))}
          </ul>

          <h3>Assign Panelists</h3>
          <select onChange={(e) => handleAssignPanelist(selectedCompetitionId, e.target.value)}>
            <option value="">Select Panelist</option>
            {panelists.map(panelist => (
              <option key={panelist.id} value={panelist.id}>{panelist.username}</option>
            ))}
          </select>
          <select onChange={(e) => setSelectedCompetitionId(e.target.value)}>
            <option value="">Select Competition</option>
            {competitions.map(competition => (
              <option key={competition.id} value={competition.id}>{competition.name}</option>
            ))}
          </select>
        </div>
      )}
    </div>
  );
}

export default AdminDashboard;
